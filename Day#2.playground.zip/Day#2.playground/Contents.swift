import UIKit

let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

let beatles = [ john , paul , george , ringo]

beatles[0]

// Bigger than 3 for beatles such as beatles[4] is given an error. Can't be bigger than 3 because of counts of elements inside in beatles arrays.

let colors = Set (["red","green","blue"])
let colors2 = Set(["red","green","blue","red","blue"])

// Set have an amazing features that if some object dublicated than they won't be display on the screen.

var name = ( first: "Taylor", last: "Swift")
name.1
name.last

//If you need a specific, fixed collection of related values where each item has a precise position or name, you should use a tuple:

let address = (house: 555, street: "Taylor Swift Avenue", city: "Nashville")

//If you need a collection of values that must be unique or you need to be able to check whether a specific item is in there extremely quickly, you should use a set:

let set = Set(["aardvark", "astronaut", "azalea"])

//If you need a collection of values that can contain duplicates, or the order of your items matters, you should use an array:

let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]

//Arrays are by far the most common of the three types.


let heights = [ "Taylor Swift" : 1.78,
"Ed Sheeran": 1.73
]

let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]

favoriteIceCream["Paul"]
favoriteIceCream["Sophie"]
favoriteIceCream["Charlotte"] // this returned response nil because we dont know what charlotte about him.

//we should change it like this,

favoriteIceCream ["Charlotte", default: "Unknown"]

//We changed it Unknown instead of nil.


// Creating Empty Collection

//This is for Dictionary
var teams = [ String:String]()
teams["Paul"] = "Red"

//This is for Array
var results = [Int]()

//This is for Sets
var words = Set<String>()
var numbers = Set<Int>()

var scores = Dictionary<String,Int>()
var results = Array<Int>()

var answers = [Bool]()

//Enumerations

let result = "failure"
let result2 = "failed"
let result3 = "fail"

enum Result {
    case success
    case failure
}

let result4 = Result.failure

//Enum Associated Values

enum Activity {
    case bored
    case running
    case talking
    case singing
}

enum Activity{
    case bored
    case running (destination: String)
    case talking (topic: String)
    case singing (volume:Int)
}
    
    let talking = Activity.talking(talking(topic: "football"))
    
//Enum Raw Values

enum Planet: Int {
    case mercury
    case venus
    case earth
    case mars
}

let earth = Planet(rawValue: 2)

enum Planet:Int{
    case mercury = 1
    case venus
    case earth
    case mars
}



import UIKit

//Day1

var favoriteShow = "Orange is the New Black"

favoriteShow = "The Good Place"

favoriteShow = "Doctor Who"

var age = 38

var str = "Hello Playground!"

var population = 8000000

var burns = """
qwe
asd
zxc
"""

var pi = 3.141

var awesome = true

var city = "İzmir"

var message = " the city name is \(city)"

let str = "Hello Playground"

let album: String = "Reputation"

let year: Int = 1989

let height : Double = 1.78

let taylorRocks : Bool = true



import UIKit

let firstCard = 11
let secondCard = 10


print(firstCard == secondCard ? "Cards are the same": "Cards are different")

//Same code without Telnary Method below like this code:

if firstCard == secondCard {
    print("Cards are same")
}
else {
    print("Cards are different")
}



let isAuthenticated = true
print ( isAuthenticated ? "Welcome": "Who are you?")


let weather = "sunny"

switch weather {
case "rain":
    print("Bring an umbrealla")
    
case "snow":
    print ("Wrap up warm")
case "sunny":
    print("wear sunglass")
    
default:
    print("Enjoy your day!")
}

let number = 465

let isMultiple = number.isMultiple(of: 7)




import UIKit


//Functions

// 1)Writting Functions

func merhaba() {
    let hosgeldin = "Hoşgeldin Aramıza"
}

merhaba()


// 2)Accepting Parameters

func numberSquare (number:Int){
    print(number * number)
}
numberSquare(number: 9)

// 3)Returning Values

func square (number: Int) -> Int {
    return number * number
}

square(number: 7)

// 4)Parameter Labels

func sayHello(to name: String) {
    print("Hello, \(name)!")
}

sayHello(to: "Yigit")

// 5)Ommiting Parameter Labels

func sayHi(_ name: String) {
    print("Hello, \(name)!")
}

sayHi("Yiğit")

// 6) Default Parameters

func grade(_ person: String, basarı: Bool = true) {
    if basarı == true {
        print("Tebrikler \(person). Dersten geçtin.")
    } else {
        print("Daha çok çalışmalısın", \(person)...)
    }
}

grade("yiğit")
//grade("yigit", basarı: false)

// 7) Variadic Functions

func square(numbers: Int...) {
    for number in numbers {
        print("\(number)'ın karesi \(number * number)'dır.")
    }
}

square(numbers: 1, 2, 3, 4, 5)


// 8) Writting Throwing Functions

enum PasswordError: Error {
    case obvious
}

func chechPassword (_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
}

// 9) Running Throwing Functions

do {
    try checkPassword("password")
    print("Şifre kullanılabilir.")
} catch {
    print("Şifre kullanılamaz!")
}

// 10) Inout Parameters

func double(number: inout Int) {
    number *= 2
}

var myNum = 10
double(number: &myNum)





